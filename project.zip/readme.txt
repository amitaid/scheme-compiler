We, Amitai Degani, Tal Zelig, declare the following to be true:

We worked on this assignment alone. We did not consult with others about this assignment, other than the teaching staff for this course.
We did not copy code either from other students or from the internet.
We did not make available this code to other students taking this course.
We are aware of the University, faculty (as specified in the �������), departmental, and course policies (as specified in the syllabus) on academic dishonesty: We realize that if we are found to have committed academic dishonesty that we shall be sent before the disciplinary committee (����� ������), fail the course, and possibly incur other penalties as decided by the disciplinary committee.